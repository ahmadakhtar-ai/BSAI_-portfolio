# Ahmad Akhtar — AI Engineer Portfolio

A responsive black-and-white personal portfolio website for Ahmad Akhtar.

## About
- **Name:** Ahmad Akhtar
- **Focus:** Artificial Intelligence
- **Education:** BS Artificial Intelligence (BSAI), 3rd Semester
- **University:** Bahauddin Zakariya University (BZU), Multan, Pakistan
- **GitHub:** https://github.com/ahmadakhtar-ai

## Included sections
- Hero section with profile photograph
- About
- Skills and technologies
- Five project cards
- Education
- Contact links

## Projects shown
1. Student Grade Calculator — Python
2. Student Management System — C++ / OOP
3. Student Marks Data Analysis — Python
4. Student Calendar
5. School Management System

**Future idea:** AI Study Assistant is clearly marked as a proposed project, not completed work.

## Run locally
Open `index.html` in a browser. No build tools are required.

## Customize
- Replace or update the profile photo at `assets/ahmad-akhtar-profile.jpg`.
- Update project descriptions and technology tags in `index.html` as needed.
- Add the exact LinkedIn profile URL and email address in the contact section when ready.

## Deploy
This is a static website and can be deployed with GitHub Pages or Vercel.
